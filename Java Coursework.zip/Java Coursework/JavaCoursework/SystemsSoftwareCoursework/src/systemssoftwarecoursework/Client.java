package systemssoftwarecoursework;

import java.net.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Bradley Evans
 */
public class Client {

    public static String username, password, FirstName, LastName, POB, POR, DOB;
    public static DataOutputStream outToServer;
    public static DataInputStream inFromServer;
    public static BufferedReader Keyboard = new BufferedReader(new InputStreamReader(System.in));
    public static Socket Socket;

    public static void main(String[] args) throws IOException {
        new Client().Setup(Socket);
    }

    public void Setup(Socket socket) throws IOException {
        Socket server = new Socket("localhost", 9090);
        System.out.println("Connected to " + server.getInetAddress());
        inFromServer = new DataInputStream(server.getInputStream());
        outToServer = new DataOutputStream(server.getOutputStream());
        new LoginPage().setVisible(true);
    }

    public void LoginInfo() throws IOException {
        try {
            outToServer.writeUTF(username+password); 
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    
    }
    public void RegisterInfo() throws IOException {
        DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
        DOB = df.format(RegisterPage.jDateChooser.getDate());
        try {
            outToServer.writeUTF(username+"//////"+ password + "//////"+FirstName+"//////"+LastName+"//////"+DOB+"//////"+POB);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
