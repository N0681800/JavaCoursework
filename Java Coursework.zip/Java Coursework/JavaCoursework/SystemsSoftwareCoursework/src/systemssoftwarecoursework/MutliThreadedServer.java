/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package systemssoftwarecoursework;

import java.net.*;
import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Bradley Evans
 */
public class MutliThreadedServer {

    public String username, password, FirstName, LastName, POB, POR, DOB, dbName = "informartion", tableName = "regdetails";
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "Wtl9";

    public Connection conn = null;
    public Statement stmt = null;
    public ResultSet rs = null;

    public static DataInputStream inFromClient;
    public static DataOutputStream outToClient;
    public static Socket client;

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(9090);
        try {
            while (true) {
                System.out.println("Waiting...");
                //establish connection
                Socket client = server.accept();
                inFromClient = new DataInputStream(client.getInputStream());
                outToClient = new DataOutputStream(client.getOutputStream());
                System.out.println("Connected" + client.getInetAddress());
                // assign the client to the handler
                Handler h = new Handler(client);
                Thread t = new Thread(h);
                t.start(); 
                new MutliThreadedServer().Run();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            server.close();
        }
    }

    //Run
    
        public void Run() {
        
        try {
            Check();
            Register();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
    //Check database exists
    public void Check() {

        try {

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
            String test = null;
            rs = conn.getMetaData().getCatalogs();

            while (rs.next()) {

                String databaseName = rs.getString(1);
                if (databaseName.equals(dbName)) {
                    test = dbName;
                }
            }

            if (test == dbName) {
                System.out.println("Proccesing request");

            } else {
                System.out.println("Sorry for the incovince, it will take a while to proccess request");
                //create database
                String ndb = "CREATE DATABASE " + dbName;
                stmt.executeUpdate(ndb);

                //Create table
                String nt = "CREATE TABLE " + dbName + "." + tableName + " "
                        + "(id INTEGER not NULL AUTO_INCREMENT, "
                        + " Username VARCHAR(255), "
                        + " Password VARCHAR(255), "
                        + " FirstName VARCHAR(255), "
                        + " LastName VARCHAR(255), "
                        + " DOB VARCHAR(255), "
                        + " POB VARCHAR(255), "
                        + " PRIMARY KEY ( id ))";
                stmt.executeUpdate(nt);

            }
            stmt.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    //Login
    public void Login() {
        //get user creditials
        Scanner reader = new Scanner(System.in);
        String user = null, pass = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
            String dbName = "informartion";
            String tableName = "regdetails";
            String sql = "SELECT username, password FROM " + dbName + "." + tableName;
            rs = stmt.executeQuery(sql);
            username = inFromClient.readUTF();
            password = inFromClient.readUTF();
            boolean test = false;
            while (rs.next()) {
                user = rs.getString("username");
                pass = rs.getString("password");

                if (username.equals(user)) {
                    System.out.println("Correct username and password");
                    test = true;
                }
            }

            if (test == false) {
                System.out.println("Wrong username and password");
            }
            rs.beforeFirst();
            reader.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                if (inFromClient != null) {
                    try {
                        inFromClient.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                if (outToClient != null) {
                    try {
                        outToClient.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }

    //Register
    public void Register() {
        try {
            System.out.println("hello");
            String details = inFromClient.readUTF();
            String[] parts = details.split("//////");
            username = parts[0];
            password = parts[1];
            FirstName = parts[2];
            LastName = parts[3];
            DOB = parts[4];
            POB = parts[5];
            System.out.println("hello");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();
            String dbName = "informartion";
            String tableName = "regdetails";
            String test = null;
            rs = conn.getMetaData().getCatalogs();
System.out.println("hello");
            String save = "INSERT INTO " + dbName + "." + tableName + "(Username ,Password,FirstName,LastName,DOB,POB)"
                    + "VALUES ('" + username + "','" + password + "','" + FirstName + "','" + LastName + "','" + DOB + "','" + POB + "')";

            stmt.executeUpdate(save);
            stmt.close();
System.out.println("hello");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (inFromClient != null) {
                try {
                    inFromClient.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            if (outToClient != null) {
                try {
                    outToClient.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
